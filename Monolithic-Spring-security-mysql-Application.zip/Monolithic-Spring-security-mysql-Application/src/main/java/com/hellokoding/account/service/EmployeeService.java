package com.hellokoding.account.service;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hellokoding.account.model.Employee;

@Service
@Transactional
public interface EmployeeService {
	
    public void createEmployee(Employee employee);
    public Employee updateEmployee(Employee employee);
    public void deleteEmployee(long id);
    public List<Employee> getAllEmployees();
    public List<Employee> getEmployee(String searchName);
    public List<Employee> getAllEmployees(String employeeName);
	public Employee getEmployee(long id);
    	
}
