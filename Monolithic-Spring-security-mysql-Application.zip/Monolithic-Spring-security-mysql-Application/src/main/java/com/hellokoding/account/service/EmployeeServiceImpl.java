package com.hellokoding.account.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hellokoding.account.model.Employee;
import com.hellokoding.account.repository.EmployeeRepository;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
	
	public EmployeeServiceImpl() {
		System.out.println("EmployeeServiceImpl()");
	}
	
    @Autowired
    private EmployeeRepository employerepository;

    @Override
    public void createEmployee(Employee employee) {
         employerepository.save(employee);
    }
    @Override
    public Employee updateEmployee(Employee employee) {
        return employerepository.saveAndFlush(employee);
      
    }
    @Override
    public void deleteEmployee(long id) {
    	employerepository.delete(id);
    }
    @Override
    public List<Employee> getAllEmployees() {
        return employerepository.findAll();
    }
    @Override
    public Employee getEmployee(long id) {
        return employerepository.findOne(id);
    }    
    @Override
    public List<Employee> getAllEmployees(String employeeName) {
    	return employerepository.findByName(employeeName);
    }
	@Override
	public List<Employee> getEmployee(String searchName) {
		return employerepository.findByName(searchName);
	}
}
